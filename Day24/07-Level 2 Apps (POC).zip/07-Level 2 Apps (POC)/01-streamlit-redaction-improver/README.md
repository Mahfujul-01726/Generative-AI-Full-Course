### How to run? Use python = 3.11

1. conda create -n llmapp python=3.11 -y

2. conda activate llmapp

3. pip install -r requirements.txt

4. streamlit run main.py



input demo:

Please, please, please, My customer, buy my product