## How to run?

1. conda create -n lang2 python=3.11 -y  

2. conda activate lang2 

3. pip install -r requirements.txt