conda create -n llmapp python=3.11 -y

conda activate llmapp

pip install -r requirements.txt




https://serper.dev/api-key