import requests
from bs4 import BeautifulSoup
import urllib.parse
import time

def search_google_ai_courses_bangla():
    """
    Search Google for generative AI courses in Bangla
    """
    print("🔍 Searching Google for Generative AI courses in Bangla...")
    print("=" * 60)
    
    # Search queries to try
    search_queries = [
        "best generative AI course in Bangla",
        "AI course Bangla YouTube",
        "generative AI tutorial Bangla",
        "machine learning course Bangla",
        "AI learning Bangladesh"
    ]
    
    results = []
    
    for query in search_queries:
        print(f"\n🔎 Searching for: '{query}'")
        
        # Encode the query for URL
        encoded_query = urllib.parse.quote(query)
        search_url = f"https://www.google.com/search?q={encoded_query}"
        
        # Headers to mimic a real browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
        
        try:
            # Make the request
            response = requests.get(search_url, headers=headers, timeout=10)
            response.raise_for_status()
            
            # Parse the HTML
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract search results
            search_results = soup.find_all('div', class_='g')
            
            print(f"   Found {len(search_results)} results")
            
            for i, result in enumerate(search_results[:5]):  # Get top 5 results
                title_element = result.find('h3')
                link_element = result.find('a')
                snippet_element = result.find('span', class_='aCOpRe')
                
                if title_element and link_element:
                    title = title_element.get_text()
                    link = link_element.get('href', '')
                    
                    # Clean the link
                    if link.startswith('/url?q='):
                        link = link.split('/url?q=')[1].split('&')[0]
                    
                    snippet = ""
                    if snippet_element:
                        snippet = snippet_element.get_text()
                    
                    results.append({
                        'title': title,
                        'link': link,
                        'snippet': snippet,
                        'query': query
                    })
                    
                    print(f"   {i+1}. {title}")
                    print(f"      {link}")
                    if snippet:
                        print(f"      {snippet[:100]}...")
                    print()
            
            # Be respectful with requests
            time.sleep(2)
            
        except Exception as e:
            print(f"   Error searching for '{query}': {str(e)}")
            continue
    
    return results

def analyze_results(results):
    """
    Analyze and categorize the search results
    """
    print("\n📊 Analysis of Search Results:")
    print("=" * 40)
    
    # Categorize results
    categories = {
        'youtube': [],
        'courses': [],
        'tutorials': [],
        'institutions': [],
        'communities': []
    }
    
    for result in results:
        title_lower = result['title'].lower()
        link_lower = result['link'].lower()
        
        if 'youtube.com' in link_lower or 'youtu.be' in link_lower:
            categories['youtube'].append(result)
        elif 'course' in title_lower or 'learning' in title_lower:
            categories['courses'].append(result)
        elif 'tutorial' in title_lower or 'guide' in title_lower:
            categories['tutorials'].append(result)
        elif 'university' in link_lower or 'institute' in link_lower:
            categories['institutions'].append(result)
        elif 'community' in title_lower or 'group' in title_lower:
            categories['communities'].append(result)
    
    # Display categorized results
    for category, items in categories.items():
        if items:
            print(f"\n🎯 {category.upper()} ({len(items)} results):")
            for item in items[:3]:  # Show top 3 per category
                print(f"   • {item['title']}")
                print(f"     {item['link']}")

def main():
    print("🤖 Google Search for Generative AI Courses in Bangla")
    print("=" * 55)
    
    # Perform the search
    results = search_google_ai_courses_bangla()
    
    if results:
        # Analyze results
        analyze_results(results)
        
        print(f"\n✅ Found {len(results)} total results")
        print("\n💡 Top Recommendations:")
        
        # Show top recommendations
        for i, result in enumerate(results[:5], 1):
            print(f"   {i}. {result['title']}")
            print(f"      {result['link']}")
            print()
    else:
        print("\n❌ No results found. This might be due to:")
        print("   • Network connectivity issues")
        print("   • Google blocking automated requests")
        print("   • Need for different search terms")
        
        print("\n🔍 Alternative Search Terms to Try:")
        alternative_terms = [
            "বাংলায় AI কোর্স",
            "generative AI বাংলা",
            "machine learning tutorial Bangladesh",
            "AI course Dhaka",
            "artificial intelligence Bangla"
        ]
        
        for term in alternative_terms:
            print(f"   • {term}")

if __name__ == "__main__":
    main() 