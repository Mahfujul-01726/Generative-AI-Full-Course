from flask import Flask, render_template_string
import os

app = Flask(__name__)

# HTML template for a modern, beautiful UI
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flask Web App</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 500px;
            width: 90%;
        }
        
        h1 {
            color: #333;
            margin-bottom: 1rem;
            font-size: 2.5rem;
            font-weight: 300;
        }
        
        p {
            color: #666;
            margin-bottom: 2rem;
            font-size: 1.1rem;
            line-height: 1.6;
        }
        
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            margin: 0.5rem;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        
        .features {
            margin-top: 2rem;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }
        
        .feature {
            background: rgba(102, 126, 234, 0.1);
            padding: 1rem;
            border-radius: 10px;
            border-left: 4px solid #667eea;
        }
        
        .feature h3 {
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .feature p {
            color: #666;
            font-size: 0.9rem;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Flask Web App</h1>
        <p>Welcome to your beautiful Flask application! This is a modern, responsive web app built with Flask and styled with CSS.</p>
        
        <div class="features">
            <div class="feature">
                <h3>⚡ Fast</h3>
                <p>Lightweight and efficient Flask framework</p>
            </div>
            <div class="feature">
                <h3>🎨 Beautiful</h3>
                <p>Modern UI with gradient backgrounds</p>
            </div>
            <div class="feature">
                <h3>📱 Responsive</h3>
                <p>Works perfectly on all devices</p>
            </div>
        </div>
        
        <div style="margin-top: 2rem;">
            <a href="/about" class="btn">About</a>
            <a href="/contact" class="btn">Contact</a>
        </div>
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    return render_template_string(HTML_TEMPLATE)

@app.route('/about')
def about():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>About - Flask App</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>About This Flask App</h1>
            <p>This is a simple Flask web application demonstrating basic routing and template rendering.</p>
            <a href="/" class="btn">Back to Home</a>
        </div>
    </body>
    </html>
    """

@app.route('/contact')
def contact():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Contact - Flask App</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
            .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Contact Us</h1>
            <p>Get in touch with us for any questions or support.</p>
            <p>Email: contact@example.com</p>
            <p>Phone: +1 (555) 123-4567</p>
            <a href="/" class="btn">Back to Home</a>
        </div>
    </body>
    </html>
    """

@app.route('/api/status')
def api_status():
    return {'status': 'running', 'message': 'Flask app is working perfectly!'}

if __name__ == '__main__':
    print("🚀 Starting Flask application...")
    print("📱 Open your browser and go to: http://localhost:5000")
    print("🔗 Available routes:")
    print("   - / (Home page)")
    print("   - /about (About page)")
    print("   - /contact (Contact page)")
    print("   - /api/status (API endpoint)")
    print("⏹️  Press Ctrl+C to stop the server")
    
    app.run(debug=True, host='0.0.0.0', port=5000)