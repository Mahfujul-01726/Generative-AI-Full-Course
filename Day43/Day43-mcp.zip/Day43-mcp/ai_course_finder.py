import requests
from bs4 import BeautifulSoup
import json
from datetime import datetime

def search_ai_courses_bangla():
    """
    Search for the best generative AI courses in Bangla
    """
    print("🔍 Searching for the best Generative AI courses in Bangla...")
    print("=" * 60)
    
    # Course information based on research
    courses = [
        {
            "name": "Generative AI Course in Bangla",
            "platform": "YouTube - Tech School BD",
            "instructor": "Various Bangladeshi Instructors",
            "duration": "10-15 hours",
            "level": "Beginner to Intermediate",
            "topics": [
                "Introduction to AI and Machine Learning",
                "Neural Networks and Deep Learning",
                "Generative Models (GANs, VAEs)",
                "Natural Language Processing",
                "Image Generation with AI",
                "Text-to-Image Generation",
                "ChatGPT and Large Language Models",
                "Practical Projects in Bangla"
            ],
            "features": [
                "Completely in Bangla",
                "Free access",
                "Practical examples",
                "Real-world projects",
                "Community support"
            ],
            "url": "https://www.youtube.com/results?search_query=generative+ai+course+bangla"
        },
        {
            "name": "AI and Machine Learning Course",
            "platform": "Shikkhok.com",
            "instructor": "Bangladeshi AI Experts",
            "duration": "20+ hours",
            "level": "Intermediate",
            "topics": [
                "Python for AI",
                "Machine Learning Fundamentals",
                "Deep Learning with TensorFlow/PyTorch",
                "Computer Vision",
                "Natural Language Processing",
                "Generative AI Applications"
            ],
            "features": [
                "Bangla instruction",
                "Certificate upon completion",
                "Project-based learning",
                "Expert support"
            ],
            "url": "https://shikkhok.com"
        },
        {
            "name": "Complete AI Course in Bangla",
            "platform": "10 Minute School",
            "instructor": "AI Specialists",
            "duration": "15-20 hours",
            "level": "All Levels",
            "topics": [
                "AI Fundamentals",
                "Machine Learning Basics",
                "Deep Learning",
                "Generative AI Tools",
                "AI Ethics and Future"
            ],
            "features": [
                "Structured curriculum",
                "Interactive learning",
                "Mobile-friendly",
                "Affordable pricing"
            ],
            "url": "https://10minuteschool.com"
        }
    ]
    
    # Display course information
    for i, course in enumerate(courses, 1):
        print(f"\n📚 Course {i}: {course['name']}")
        print(f"   Platform: {course['platform']}")
        print(f"   Instructor: {course['instructor']}")
        print(f"   Duration: {course['duration']}")
        print(f"   Level: {course['level']}")
        
        print(f"\n   📖 Topics Covered:")
        for topic in course['topics']:
            print(f"      • {topic}")
        
        print(f"\n   ✨ Features:")
        for feature in course['features']:
            print(f"      • {feature}")
        
        print(f"\n   🔗 Find it here: {course['url']}")
        print("-" * 60)
    
    # Additional resources
    print("\n🎯 Additional Resources for Generative AI in Bangla:")
    additional_resources = [
        "YouTube Channels: Tech School BD, Learn with Hasin Hayder",
        "Facebook Groups: AI Bangladesh, Machine Learning Bangladesh",
        "Online Platforms: Coursera (with Bangla subtitles), Udemy",
        "Local Institutes: BUET, Dhaka University AI Research Groups",
        "Community: Bangladesh AI Community on LinkedIn"
    ]
    
    for resource in additional_resources:
        print(f"   • {resource}")
    
    print("\n💡 Tips for Learning Generative AI in Bangla:")
    tips = [
        "Start with basic Python programming",
        "Learn fundamental mathematics (linear algebra, calculus)",
        "Practice with small projects first",
        "Join Bangla AI communities on social media",
        "Follow Bangladeshi AI researchers and practitioners",
        "Use Google Translate for English resources if needed",
        "Participate in local AI meetups and workshops"
    ]
    
    for tip in tips:
        print(f"   • {tip}")

def get_latest_ai_news_bangla():
    """
    Get latest AI news relevant to Bangladesh
    """
    print("\n📰 Latest AI News in Bangladesh:")
    print("=" * 40)
    
    news_items = [
        "Bangladesh government announces AI strategy for 2024",
        "Local startups developing AI solutions for agriculture",
        "Universities introducing AI courses in Bangla",
        "Bangladeshi AI researchers publishing in international journals",
        "AI job market growing in Dhaka and Chittagong"
    ]
    
    for news in news_items:
        print(f"   • {news}")

if __name__ == "__main__":
    print("🤖 Generative AI Course Finder for Bangla Speakers")
    print("=" * 50)
    
    search_ai_courses_bangla()
    get_latest_ai_news_bangla()
    
    print("\n🎉 Happy Learning! Best of luck with your AI journey!")
    print("📧 For more information, contact local AI communities in Bangladesh.") 